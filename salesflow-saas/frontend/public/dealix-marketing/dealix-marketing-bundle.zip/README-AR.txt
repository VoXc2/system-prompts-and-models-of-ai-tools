﻿Ø¨Ø¹Ø¯ ÙÙƒ Ø§Ù„Ø¶ØºØ·:
- Ø§ÙØªØ­ dealix-marketing/index.html ÙÙŠ Ø§Ù„Ù…ØªØµÙØ­ (ÙŠØ¹Ù…Ù„ Ù…Ø­Ù„ÙŠØ§Ù‹ Ø¨Ø¯ÙˆÙ† Ø®Ø§Ø¯Ù… Ø¥Ø°Ø§ Ø¨Ù‚ÙŠ dealix-presentations Ø¨Ø¬Ø§Ù†Ø¨ dealix-marketing).
- Ù„Ø§ ØªÙ†Ù‚Ù„ Ù…Ø¬Ù„Ø¯Ø§Ù‹ ÙˆØ§Ø­Ø¯Ø§Ù‹ ÙÙ‚Ø·Ø› Ø§Ù„Ø±ÙˆØ§Ø¨Ø· Ø¨ÙŠÙ† Ø§Ù„Ù…Ø¬Ù„Ø¯ÙŠÙ† Ù†Ø³Ø¨ÙŠØ©.
- Ø¹Ø¨Ø± Next.js: npm run dev Ø«Ù… http://localhost:3000/dealix-marketing/
